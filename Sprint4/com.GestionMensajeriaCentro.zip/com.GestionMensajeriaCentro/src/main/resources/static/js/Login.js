// login.js: por ahora vacío, se puede usar para validaciones futuras
console.log("Login JS cargado");
