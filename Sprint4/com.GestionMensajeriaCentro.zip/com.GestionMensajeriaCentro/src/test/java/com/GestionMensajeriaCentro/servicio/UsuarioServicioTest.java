package com.GestionMensajeriaCentro.servicio;

import org.junit.jupiter.api.Test;

class UsuarioServicioTest {

    @Test
    void findAll() {
    }

    @Test
    void findById() {
    }

    @Test
    void findByEmail() {
    }

    @Test
    void existsByEmail() {
    }

    @Test
    void save() {
    }

    @Test
    void deleteById() {
    }
}